package com.example.quanly.GiaoDien;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.quanly.R;

public class MenuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);
    }
}