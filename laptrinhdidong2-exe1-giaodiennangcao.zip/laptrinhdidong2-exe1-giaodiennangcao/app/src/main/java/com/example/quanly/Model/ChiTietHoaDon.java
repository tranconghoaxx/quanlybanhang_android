package com.example.quanly.Model;

public class ChiTietHoaDon {
    String maHD,maSP,soluongSP;

    public String getMaHD() {
        return maHD;
    }

    public void setMaHD(String maHD) {
        this.maHD = maHD;
    }

    public String getMaSP() {
        return maSP;
    }

    public void setMaSP(String maSP) {
        this.maSP = maSP;
    }

    public String getSoluongSP() {
        return soluongSP;
    }

    public void setSoluongSP(String soluongSP) {
        this.soluongSP = soluongSP;
    }
}
